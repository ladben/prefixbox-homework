const filterInput = document.querySelector('input.sale');
const orderInput = document.querySelector('select.order');
const products = document.querySelectorAll('.product');

const productsArr = Array.prototype.slice.call(products).map(e => {
  const productData = {
    id: e.children[1].dataset.identifier,
    productName: e.children[1].children[0].textContent,
    price: convertPriceStringToNumber(e.children[1].children[1].textContent)
  }
  return productData;
});

filterInput.onchange = handleFilter;

orderInput.onchange = () => {
  handleOrder(productsArr, products);
};

// filtering event handler

function handleFilter (event) {
  products.forEach(e => {
    if (event.target.checked) {
      const oldPrice = e.querySelector('.product-old-price');
      if (!oldPrice) {
        e.style.display = 'none';
      }
    } else {
      e.style.display = 'inline-block';
    }
  });
}

// sorting logic

const sortAscByProductName = function (a, b) {
  if (a.productName < b.productName) {
    return -1;
  } else if (a.productName > b.productName) {
    return 1;
  } else {
    return 0;
  }
}
const sortDescByProductName = function (a, b) {
  return (-1 * sortAscByProductName(a, b));
}
const sortAscByPrice = function (a, b) {
  if (a.price < b.price) {
    return -1;
  } else if (a.price > b.price) {
    return 1;
  } else {
    return 0;
  }
}
const sortDescByPrice = function (a, b) {
  return (-1 * sortAscByPrice(a, b));
}

function orderElementArray (elements, orderType) {
  let newElements = [...elements];
  switch (orderType) {
    case 0:
      newElements.sort(sortAscByPrice);
      break;
    case 1:
      newElements.sort(sortDescByPrice);
      break;
    case 2:
      newElements.sort(sortAscByProductName);
      break;
    case 3:
      newElements.sort(sortDescByProductName);
      break;
    default:
      throw new Error ('Wrong order type given');
  }
  return newElements;
}

// order event handler

function handleOrder (elements, elementsNodeList) {
  const orderType = parseInt(orderInput.options[orderInput.selectedIndex].value);
  const orderedProductArr = orderElementArray(elements, orderType);
  const wrapper = document.querySelector('.products');
  const orderedElements = document.createDocumentFragment();

  orderedProductArr.forEach(productElement => {
    const id = productElement.id;
    elementsNodeList.forEach(nodeElement => {
      if (nodeElement.querySelector('.product-data').dataset.identifier === id) {
        orderedElements.appendChild(nodeElement);
      }
    })
  });

  wrapper.innerHTML = null;
  wrapper.appendChild(orderedElements);
}

// utility functions

function convertPriceStringToNumber (priceStr) {
  const priceStrWithoutCurrency = priceStr.split(' Ft')[0];
  const priceStrWithoutDividingDots = priceStrWithoutCurrency.split('.').join('');
  return parseInt(priceStrWithoutDividingDots);
}